
The purpose of this program is to create a surf report based on three different factors wind, storms, and tide.
The program is initialized by telling ALexa to open "hows the surf" and then asking for a surf report according to 
the sample utterances for the report function. When in doubt just ask hows the surf "hows the surf?" The program will
proceed to ask you what direction the wind is going. The program also gives directions on how to answer as certain
keywords are needed for the program to work as intended. A function following the question will use your answer to 
determine a sentence to add to your report based on the condition. The next question will then be asked regarding
nearby storms. Like the wind question, there is a desired way to answer the storm question that the question gives you.
For this question, if you do not say yes or no, no sentence will be added to the report. The final question will then
ask you about tide. Like the last two questions you are given a format to answer. If no answers match what the program
is looking for no sentence will be added to the surf report. Lastly, the report will be given to you after you answer
the final question.

# ap-computer-science-final-project-zanemrazekcs
ap-computer-science-final-project-zanemrazekcs created by GitHub Classroom
